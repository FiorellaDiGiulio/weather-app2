import { setWeatherAnimation } from "./weatherAnimations.js";

// Karta från Open-Meteo weather codes → animation
export function codeToAnimation(code) {
    if ([0].includes(code)) return "sun";
    if ([1, 2, 3].includes(code)) return "cloud";

    if ([45, 48].includes(code)) return "fog";

    if ([51, 53, 55].includes(code)) return "rain";
    if ([61, 63, 65].includes(code)) return "rain";
    if ([80, 81, 82].includes(code)) return "rain";

    if ([71, 73, 75, 77].includes(code)) return "snow";
    if ([85, 86].includes(code)) return "snow";

    if ([95, 96, 99].includes(code)) return "thunder";

    return "";
}

export function applyWeatherEffects(weather) {
    if (!weather?.weather?.[0]) return;

    const code = weather.weather[0].code;
    const animation = codeToAnimation(code);

    // Starta själva animationen
    setWeatherAnimation(animation);

    // Dynamisk bakgrund (fade)
    const bg = document.querySelector(".weather-bg");

    switch (animation) {
        case "sun":
            bg.style.setProperty("--top", "#ffcc7a");
            bg.style.setProperty("--bottom", "#ff9a3c");
            break;

        case "cloud":
            bg.style.setProperty("--top", "#d8d8d8");
            bg.style.setProperty("--bottom", "#9ea3a8");
            break;

        case "rain":
            bg.style.setProperty("--top", "#6e7a89");
            bg.style.setProperty("--bottom", "#3c434d");
            break;

        case "snow":
            bg.style.setProperty("--top", "#e6f2ff");
            bg.style.setProperty("--bottom", "#bcd6f9");
            break;

        case "fog":
            bg.style.setProperty("--top", "#e4e4e4");
            bg.style.setProperty("--bottom", "#bfbfbf");
            break;

        case "thunder":
            bg.style.setProperty("--top", "#2a2a33");
            bg.style.setProperty("--bottom", "#1a1a20");
            break;
    }
}

